# Prompt 06 — Forum communautaire par filière (Should Have)

## Prompt à copier-coller

Implémente un forum / espace questions-réponses organisé par filière, en t'appuyant sur templates/schema_bdd.md (crée les tables nécessaires si absentes : sujets, réponses).

Fonctionnalités :
- Liste des filières/thématiques (entité GroupeThématique).
- Créer un sujet, répondre à un sujet.
- Tri par activité récente.
- Signalement d'un sujet/d'une réponse (utilisé par le prompt 08 — modération).

Contraintes : RLS, pagination pour rester léger, mobile-first. Propose le plan avant d'exécuter.
